import sys

def print_error(message):
    print(message, file=sys.stderr)